from app import app, db, SearchResult

with app.app_context():
    print('数据库连接:', db.engine.url)
    print('SearchResult表是否存在:', db.inspect(db.engine).has_table('search_result'))
    print('现有数据数量:', SearchResult.query.count())
