from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, send_file
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import json
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.units import inch
import io

# 创建Flask应用
app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///data.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# 初始化数据库
db = SQLAlchemy(app)

# 初始化登录管理器
login_manager = LoginManager(app)
login_manager.login_view = 'login'

# 用户模型
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.String(100), nullable=False)

# 搜索结果模型
class SearchResult(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    keyword = db.Column(db.String(100), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    abstract = db.Column(db.Text, nullable=False)
    link = db.Column(db.String(500), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

# AI提炼结果模型
class AIExtractResult(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    keyword = db.Column(db.String(100), nullable=False)
    original_data_ids = db.Column(db.Text, nullable=False)  # 存储原始数据ID，用逗号分隔
    extract_content = db.Column(db.Text, nullable=False)    # AI提炼的内容
    summary = db.Column(db.Text, nullable=False)            # 提炼摘要
    insights = db.Column(db.Text, nullable=False)           # 关键洞察
    recommendations = db.Column(db.Text, nullable=False)    # 建议
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

# 加载用户
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# 登录路由
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username, password=password).first()
        if user:
            login_user(user)
            return redirect(url_for('index'))
        else:
            flash('用户名或密码错误')
    return render_template('login.html')

# 登出路由
@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

# 主页路由
@app.route('/', methods=['GET', 'POST'])
@login_required
def index():
    results = []
    if request.method == 'POST':
        keyword = request.form['keyword']
        try:
            # 直接调用爬虫类的search方法，而不是通过subprocess
            from baidu_spider import BaiduSearchSpider
            spider = BaiduSearchSpider()
            results = spider.search(keyword)
            
            # 为每个结果添加keyword字段，以便后续保存
            for result in results:
                result['keyword'] = keyword
                
        except Exception as e:
            flash(f'调用爬虫失败: {e}')
    return render_template('index.html', results=results)

# 保存结果到数据库
@app.route('/save_results', methods=['POST'])
@login_required
def save_results():
    try:
        data = request.get_json()
        if not data or not isinstance(data, list):
            return {'status': 'error', 'message': '无效的数据格式'}
        
        for item in data:
            result = SearchResult(
                keyword=item.get('keyword', ''),
                title=item.get('title', ''),
                abstract=item.get('abstract', ''),
                link=item.get('link', '')
            )
            db.session.add(result)
        
        db.session.commit()
        return {'status': 'success', 'message': '数据保存成功'}
    except Exception as e:
        return {'status': 'error', 'message': str(e)}

# 数据仓库路由
@app.route('/data_warehouse', methods=['GET'])
@login_required
def data_warehouse():
    keyword = request.args.get('keyword', '')
    date = request.args.get('date', '')
    
    query = SearchResult.query
    
    if keyword:
        query = query.filter(
            (SearchResult.title.contains(keyword)) | 
            (SearchResult.abstract.contains(keyword)) |
            (SearchResult.keyword.contains(keyword))
        )
    
    if date:
        try:
            date_obj = datetime.strptime(date, '%Y-%m-%d')
            query = query.filter(
                db.func.date(SearchResult.created_at) == db.func.date(date_obj)
            )
        except ValueError:
            flash('无效的日期格式')
    
    results = query.order_by(SearchResult.created_at.desc()).all()
    return render_template('data_warehouse.html', results=results)


# 删除单条数据路由
@app.route('/delete_data', methods=['POST'])
@login_required
def delete_data():
    try:
        data = request.get_json()
        data_id = data.get('id')
        
        if not data_id:
            return jsonify({'success': False, 'message': '缺少数据ID'}), 400
        
        # 查询要删除的数据
        result = SearchResult.query.get(data_id)
        if not result:
            return jsonify({'success': False, 'message': '数据不存在'}), 404
        
        # 删除数据
        db.session.delete(result)
        db.session.commit()
        
        return jsonify({'success': True, 'message': '删除成功'})
        
    except Exception as e:
        app.logger.error(f"删除数据失败: {str(e)}")
        return jsonify({'success': False, 'message': '删除失败: ' + str(e)}), 500


# 删除选中的数据路由
@app.route('/delete_selected_data', methods=['POST'])
@login_required
def delete_selected_data():
    try:
        data = request.get_json()
        ids = data.get('ids', [])
        
        if not ids or not isinstance(ids, list):
            return jsonify({'success': False, 'message': '缺少数据ID列表'}), 400
        
        # 查询要删除的数据
        results = SearchResult.query.filter(SearchResult.id.in_(ids)).all()
        if not results:
            return jsonify({'success': False, 'message': '未找到选中的数据'}), 404
        
        # 删除数据
        for result in results:
            db.session.delete(result)
        db.session.commit()
        
        return jsonify({'success': True, 'message': '删除成功'})
        
    except Exception as e:
        app.logger.error(f"删除选中数据失败: {str(e)}")
        return jsonify({'success': False, 'message': '删除失败: ' + str(e)}), 500

# AI数据提炼路由
@app.route('/ai_extract', methods=['POST'])
@login_required
def ai_extract():
    try:
        data = request.get_json()
        result_ids = data.get('result_ids', [])
        
        if not result_ids:
            return jsonify({'status': 'error', 'message': '请选择要提炼的数据'})
        
        # 从数据库获取选中的数据
        results = SearchResult.query.filter(SearchResult.id.in_(result_ids)).all()
        
        if not results:
            return jsonify({'status': 'error', 'message': '未找到选中的数据'})
        
        # 准备数据供AI分析
        keywords = set(result.keyword for result in results)
        keyword = ', '.join(keywords) if keywords else '无关键词'
        
        # 收集所有内容
        all_content = ''
        for result in results:
            all_content += f"标题: {result.title}\n"
            all_content += f"摘要: {result.abstract}\n"
            all_content += f"链接: {result.link}\n\n"
        
        # 模拟AI分析结果（实际项目中这里会调用真实的AI API）
        ai_summary = f"基于{len(results)}条搜索结果的分析摘要：本次分析围绕关键字'{keyword}'展开，主要涵盖了相关领域的最新动态和发展趋势。"
        ai_insights = f"关键洞察：1. 搜索结果显示该领域正处于快速发展阶段；2. 相关技术应用广泛；3. 市场需求持续增长。"
        ai_recommendations = f"建议：1. 持续关注该领域的最新发展；2. 加强技术研发和创新；3. 拓展相关应用场景。"
        ai_extract_content = f"# AI数据提炼报告\n\n## 摘要\n{ai_summary}\n\n## 关键洞察\n{ai_insights}\n\n## 建议\n{ai_recommendations}\n\n## 原始数据来源\n共{len(results)}条记录，关键字：{keyword}"
        
        # 保存AI提炼结果到数据库
        original_data_ids_str = ','.join(map(str, result_ids))
        ai_result = AIExtractResult(
            keyword=keyword,
            original_data_ids=original_data_ids_str,
            extract_content=ai_extract_content,
            summary=ai_summary,
            insights=ai_insights,
            recommendations=ai_recommendations
        )
        db.session.add(ai_result)
        db.session.commit()
        
        # 返回结果
        return jsonify({
            'status': 'success',
            'message': 'AI数据提炼完成',
            'extract_id': ai_result.id,
            'summary': ai_summary,
            'insights': ai_insights,
            'recommendations': ai_recommendations
        })
        
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)})

# 生成PDF报告路由
@app.route('/ai_results')
@login_required
def ai_results():
    # 获取筛选参数
    keyword = request.args.get('keyword')
    date = request.args.get('date')
    
    # 查询AI提炼结果
    query = AIExtractResult.query.order_by(AIExtractResult.created_at.desc())
    
    # 添加筛选条件
    if keyword:
        query = query.filter(AIExtractResult.keyword.like(f'%{keyword}%'))
    
    if date:
        query = query.filter(db.func.date(AIExtractResult.created_at) == date)
    
    # 获取数据
    ai_results = query.all()
    
    return render_template('ai_results.html', ai_results=ai_results)


@app.route('/generate_pdf', methods=['POST'])
@login_required
def generate_pdf():
    try:
        data = request.get_json()
        # 支持从数据仓库中选择的数据ID列表
        selected_ids = data.get('selected_ids', [])
        # 支持从搜索结果中选择的数据ID列表
        result_ids = data.get('result_ids', [])
        ai_extract_id = data.get('ai_extract_id', None)
        
        # 如果提供了selected_ids，优先使用它
        if selected_ids:
            result_ids = selected_ids
        
        if ai_extract_id:
            # 生成AI提炼结果的PDF报告
            ai_result = AIExtractResult.query.get(ai_extract_id)
            if not ai_result:
                return jsonify({'status': 'error', 'message': '未找到AI提炼结果'})
            
            # 创建PDF文档
            buffer = io.BytesIO()
            doc = SimpleDocTemplate(buffer, pagesize=A4, topMargin=inch, bottomMargin=inch, leftMargin=inch, rightMargin=inch)
            
            # 设置样式
            styles = getSampleStyleSheet()
            title_style = styles['Title']
            heading_style = styles['Heading1']
            body_style = styles['BodyText']
            
            # 创建内容
            content = []
            
            # 添加标题
            title = Paragraph('AI智能数据分析报告', title_style)
            content.append(title)
            content.append(Spacer(1, 0.5*inch))
            
            # 添加报告信息
            report_info = f"生成日期: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
            content.append(Paragraph(report_info, body_style))
            content.append(Spacer(1, 0.5*inch))
            
            # 添加AI提炼摘要
            content.append(Paragraph('报告摘要', heading_style))
            content.append(Spacer(1, 0.25*inch))
            content.append(Paragraph(ai_result.summary, body_style))
            content.append(Spacer(1, 0.5*inch))
            
            # 添加关键洞察
            content.append(Paragraph('关键洞察', heading_style))
            content.append(Spacer(1, 0.25*inch))
            content.append(Paragraph(ai_result.insights, body_style))
            content.append(Spacer(1, 0.5*inch))
            
            # 添加建议
            content.append(Paragraph('建议与推荐', heading_style))
            content.append(Spacer(1, 0.25*inch))
            content.append(Paragraph(ai_result.recommendations, body_style))
            content.append(Spacer(1, 0.5*inch))
            
            # 添加原始数据来源
            content.append(Paragraph('原始数据来源', heading_style))
            content.append(Spacer(1, 0.25*inch))
            original_data_ids = list(map(int, ai_result.original_data_ids.split(',')))
            source_results = SearchResult.query.filter(SearchResult.id.in_(original_data_ids)).all()
            
            if source_results:
                # 原始数据表格
                table_data = [['关键词', '标题', '链接']]
                for result in source_results:
                    table_data.append([
                        result.keyword,
                        result.title,
                        result.link
                    ])
                
                # 创建表格
                table = Table(table_data, colWidths=[1.5*inch, 3.5*inch, 3*inch])
                
                # 设置表格样式
                table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                    ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, 0), 12),
                    ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                    ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                    ('GRID', (0, 0), (-1, -1), 1, colors.black)
                ]))
                
                content.append(table)
        
        else:
            # 生成常规搜索结果的PDF报告
            if not result_ids:
                return jsonify({'status': 'error', 'message': '请选择要生成报告的数据'})
            
            # 从数据库获取选中的数据
            results = SearchResult.query.filter(SearchResult.id.in_(result_ids)).all()
            
            if not results:
                return jsonify({'status': 'error', 'message': '未找到选中的数据'})
            
            # 创建PDF文档
            buffer = io.BytesIO()
            doc = SimpleDocTemplate(buffer, pagesize=A4, topMargin=inch, bottomMargin=inch, leftMargin=inch, rightMargin=inch)
            
            # 设置样式
            styles = getSampleStyleSheet()
            title_style = styles['Title']
            heading_style = styles['Heading1']
            body_style = styles['BodyText']
            
            # 创建内容
            content = []
            
            # 添加标题
            title = Paragraph('智能瞭望数据分析报告', title_style)
            content.append(title)
            content.append(Spacer(1, 0.5*inch))
            
            # 添加报告信息
            report_info = f"生成日期: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
            content.append(Paragraph(report_info, body_style))
            content.append(Spacer(1, 0.5*inch))
            
            # 添加数据表格
            if results:
                # 表格标题
                table_title = Paragraph('搜索结果数据', heading_style)
                content.append(table_title)
                content.append(Spacer(1, 0.25*inch))
                
                # 表格数据
                table_data = [['关键词', '标题', '链接']]
                for result in results:
                    table_data.append([
                        result.keyword,
                        result.title,
                        result.link
                    ])
                
                # 创建表格
                table = Table(table_data, colWidths=[1.5*inch, 3.5*inch, 3*inch])
                
                # 设置表格样式
                table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                    ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, 0), 12),
                    ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                    ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                    ('GRID', (0, 0), (-1, -1), 1, colors.black)
                ]))
                
                content.append(table)
                content.append(Spacer(1, 0.5*inch))
            
            # 添加详细内容
            content.append(Paragraph('详细内容', heading_style))
            content.append(Spacer(1, 0.25*inch))
            
            for result in results:
                content.append(Paragraph(f"关键词: {result.keyword}", body_style))
                content.append(Paragraph(f"标题: {result.title}", body_style))
                content.append(Paragraph(f"摘要: {result.abstract}", body_style))
                content.append(Paragraph(f"链接: {result.link}", body_style))
                content.append(Paragraph(f"添加时间: {result.created_at.strftime('%Y-%m-%d %H:%M:%S')}", body_style))
                content.append(Spacer(1, 0.5*inch))
        
        # 生成PDF
        doc.build(content)
        
        # 重置缓冲区位置
        buffer.seek(0)
        
        # 返回PDF文件
        return send_file(buffer, as_attachment=True, download_name='analysis_report.pdf', mimetype='application/pdf')
        
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)})

# 初始化数据库和默认用户
def init_db():
    with app.app_context():
        db.create_all()
        # 创建默认管理员用户
        admin = User.query.filter_by(username='admin').first()
        if not admin:
            admin = User(username='admin', password='admin888')
            db.session.add(admin)
            db.session.commit()

if __name__ == '__main__':
    init_db()
    app.run(debug=True)