import requests
from bs4 import BeautifulSoup

class BaiduSearchSpider:
    def __init__(self):
        # 设置请求头
        self.headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
            'cache-control': 'max-age=0',
            'connection': 'keep-alive',
            'cookie': 'BIDUPSID=EB4FAA663B698F183E2CCBD43ED71B8F; PSTM=1764748089; BD_UPN=12314753; BAIDUID=D6BC1995701A6A278D48CF6FB5EF61B2:FG=1; H_WISE_SIDS_BFESS=110085_658259_660927_667682_675507_675807_675860_676272_675242_675229_676689_676858_677025_675077_677402_677461_677701_677775_677993_676147_653709_678135_669418_678379_678376_678646_678658_678547_678688_678449_678963_676609_678932_678936_679063_679061_679080_678981_679065_679193_679188_676451_679432_679433_679463_678258_679547_673654_679697_679609_675908_679649; BAIDUID_BFESS=D6BC1995701A6A278D48CF6FB5EF61B2:FG=1; delPer=0; BD_CK_SAM=1; PSINO=1; H_WISE_SIDS=63147_64004_65311_66124_66227_66167_66381_66286_66268_66393_66529_66549_66584_66592_66600_66654_66679_66667_66693_66697_66683_66743_66618_66789_66793_66802_66804_66599_66815; H_PS_PSSID=63147_64004_65311_66124_66227_66167_66381_66286_66268_66393_66529_66549_66573_66584_66592_66600_66654_66679_66667_66693_66697_66683_66743_66618_66789_66793_66802_66804_66599_66815; BD_HOME=1; BA_HECTOR=8ga501a50k2501212k252080050l8g1kj2nmo24; ZFY=hsRMO71T:AU0WStJzSb5wRqxNVxVGZ11r3H2cw5s3mjk:C; BDORZ=B490B5EBF6F3CD402E515D22BCDA1598; H_PS_645EC=1f45T3DzXU6VppAZ%2BNbR1z88TpVLBizQQfwPuWh0bYPmwIa6lMiIMpJGqVw; baikeVisitId=dadacd61-ebfe-434e-a4f0-9611af896eb7',
            'host': 'www.baidu.com',
            'sec-ch-ua': '"Chromium";v="142", "Microsoft Edge";v="142", "Not_A Brand";v="99"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'none',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0'
        }
    
    def search(self, keyword):
        """
        搜索关键词并返回结果
        :param keyword: 搜索关键词
        :return: 搜索结果列表
        """
        try:
            # 构建请求URL
            url = f'https://www.baidu.com/s?wd={keyword}'
            
            # 发送请求
            response = requests.get(url, headers=self.headers)
            response.encoding = 'utf-8'
            
            # 解析HTML
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # 提取搜索结果
            results = []
            # 尝试不同的选择器
            search_items = soup.find_all('div', class_='result')
            if not search_items:
                search_items = soup.find_all('div', class_='c-container')
            
            for item in search_items:
                # 提取标题
                title = item.find('h3')
                if not title:
                    title = item.find('h2')
                if title:
                    title_text = title.get_text(strip=True)
                else:
                    title_text = '无标题'
                
                # 提取摘要
                abstract = item.find('div', class_='c-abstract')
                if not abstract:
                    abstract = item.find('div', class_='abstract')
                if abstract:
                    abstract_text = abstract.get_text(strip=True)
                else:
                    abstract_text = '无摘要'
                
                # 提取链接
                link = item.find('a')
                if link and link.get('href'):
                    link_url = link.get('href')
                else:
                    link_url = '无链接'
                
                # 添加到结果列表
                results.append({
                    'title': title_text,
                    'abstract': abstract_text,
                    'link': link_url
                })
            
            return results
        except Exception as e:
            print(f"搜索出错: {e}")
            return []

import sys

if __name__ == '__main__':
    # 创建爬虫实例
    spider = BaiduSearchSpider()
    
    # 获取关键词（支持命令行参数或用户输入）
    if len(sys.argv) > 1:
        keyword = sys.argv[1]
    else:
        keyword = input("请输入搜索关键词: ")
    
    # 执行搜索
    results = spider.search(keyword)
    
    # 输出结果
    print(f"\n共找到 {len(results)} 条结果:\n")
    for i, result in enumerate(results, 1):
        print(f"{i}. 标题: {result['title']}")
        print(f"   摘要: {result['abstract']}")
        print(f"   链接: {result['link']}")
        print("-" * 50)